﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L11_DL_1069322
{
    internal class Program
    {

        static void Main(string[] args)
        {
            double[] seccion1 = new double[4]; 
            double[] seccion2 = new double[6];
            double aprobados1 = 0;
            double desaprobados1 = 0;
            double aprobados2 = 0;
            double desaprobados2 = 0;
            double totalseccion1 = 0;
            double totalseccion2 = 0;

            double porcentaje1;
            double porcentaje2;
            double porcentajedesaprobado1;
            double porcentajedesaprobado2;
            double totalporcentajeaprobados;
            double totalporcentajedesaprobados;
            double promedioseccion1;
            double promedioseccion2;
            double totalpromedio;

            int suma1 = 0;
            int suma2 = 0;
            int suma3 = 0;
            int suma4 = 0;
            int encimadelpromedio;
            int debajodelpromedio;

            for (int i = 0; i < 4; i++)
            {
                Console.WriteLine("Ingrese nota del estudiante " + (i + 1) + " de la Sección 1:");
                seccion1[i] = Convert.ToDouble(Console.ReadLine());
            }

            for (int i = 0; i < 6; i++)
            {
                Console.WriteLine("Ingrese nota del estudiante " + (i + 1) + " de la Sección 2:");
                seccion2[i] = Convert.ToDouble(Console.ReadLine());
            }
            for (int i = 0; i < 4; i++)
            {
                totalseccion1 = totalseccion1 + seccion1[i];
                if (seccion1[i] > 65)
                {
                    aprobados1 = aprobados1 + seccion1[i];
                }
                else
                {
                    desaprobados1 = desaprobados1 + seccion1[i];
                }
            }
            for (int i = 0; i < 6; i++)
            {
                totalseccion2 = totalseccion2 + seccion2[i];
                if (seccion2[i] > 65)
                {
                    aprobados2 = aprobados2 + seccion2[i];
                }
                else
                {
                    desaprobados2 = desaprobados2 + seccion2[i];
                }
            }

            porcentaje1 = (aprobados1 / totalseccion1) * 100;

            porcentajedesaprobado1 = (desaprobados1 / totalseccion1) * 100;

            porcentaje2 = (aprobados2 / totalseccion2) * 100;

            porcentajedesaprobado2 = (aprobados2 / totalseccion2) * 100;

            totalporcentajeaprobados = ((aprobados1 + aprobados2) / (totalseccion1 + totalseccion2) * 100);

            totalporcentajedesaprobados = ((desaprobados1 + desaprobados2) / (totalseccion1 + totalseccion2) * 100);

            promedioseccion1 = totalseccion1 / 5;

            promedioseccion2 = totalseccion2 / 5;

            totalpromedio = ((promedioseccion1 + promedioseccion2) / 10);

            Console.WriteLine("Porcentaje de aprobados de la Sección 1 es de: " + porcentaje1);
            Console.WriteLine("Porcentaje de desaprobados de la Sección 1 es de: " + porcentajedesaprobado1);
            Console.WriteLine("Porcentaje de aprobados de la Sección 2 es: " + porcentaje2);
            Console.WriteLine("Porcentaje de desaprobados de la Sección 2 es: " + porcentajedesaprobado2);
            Console.WriteLine("Porcentaje total de aprobados es: " + totalporcentajeaprobados);
            Console.WriteLine("Total de porcentajes desaprobados es: " + totalporcentajedesaprobados);
            Console.WriteLine("Promedio de la sección 1 es de: " + promedioseccion1);
            Console.WriteLine("Promedio de la sección 2 es de: " + promedioseccion2);
            Console.WriteLine("Promedio total es de: " + totalpromedio);

            for (int i = 0; i < 4; i++)
            {
                if (seccion1[i] > 90)
                {
                    suma1++;
                }
            }
            for (int i = 0; i < 4; i++)
            {
                if (seccion1[i] < 75)
                {
                    suma2++;
                }
            }
            for (int i = 0; i < 6; i++)
            {
                if (seccion2[i] > 90)
                {
                    suma3++;
                }
            }
            for (int i = 0; i < 4; i++)
            {
                if (seccion1[i] < 75)
                {
                    suma4++;
                }
            }
            encimadelpromedio = suma1 + suma3;

            debajodelpromedio = suma2 + suma4;

            Console.WriteLine("Los estudiantes con promedio por encima de 90 es de: " + encimadelpromedio);
            Console.WriteLine("Los estudiantes con promedio por debajo de 75 es de: " + debajodelpromedio);
            Console.ReadKey();
        }
    }
}