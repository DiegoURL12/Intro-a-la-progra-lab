﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_Fase_II
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool Inicio = true;
            double PromMin = 0;
            double PromMax = 0;
            DateTime HoraSistema;
            DateTime HoraSistemaFin;
            DateTime HoraInicio = new DateTime();
            DateTime HoraFin = new DateTime();
            int[] Habitacion = new int[2];
            int[] HabitacionMin = new int[2];
            int[] HabitacionMax = new int[2];
            while (Inicio == true)
            {
                Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
                Console.WriteLine("1. Ventilación");
                Console.WriteLine("2. Calefacción");
                Console.WriteLine("3. Iluminación");
                Console.WriteLine("4. Panel de Control");
                Console.WriteLine("5. Salir");
                Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
                try
                {
                    int Opccion = int.Parse(Console.ReadLine());
                    switch (Opccion)
                    {
                        case 1:
                            Console.WriteLine("Acceso denegado el usuario debe ingresar al panel de control");
                            Console.WriteLine("Presione enter...");
                            Console.ReadKey();
                            break;

                        case 2:
                            Console.WriteLine("Acceso denegado el usuario debe ingresar al panel de control");
                            Console.WriteLine("Presione enter...");
                            Console.ReadKey();
                            break;
                        case 3:
                            Console.WriteLine("Acceso denegado el usuario debe ingresar al panel de control");
                            Console.WriteLine("Presione enter...");
                            Console.ReadKey();
                            break;
                        case 4:
                            Panel_De_Control();
                            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
                            break;
                        case 0:
                            Inicio = false;
                            Console.WriteLine("Feliz Día........");
                            Console.ReadKey();
                            break;
                    }
                    Console.Clear();
                }
                catch (Exception)
                {
                    throw new Exception("No ingreso ninguna opción");
                }
                Console.Clear();

                
            }

            void Panel_De_Control()
            {
                Console.Clear();               
                Console.WriteLine("Menú de opción del Panel de Control:");
                Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
                Console.WriteLine("1. Configuracion Ventilación");
                Console.WriteLine("2. Configuracion Calefacción");
                Console.WriteLine("3. Datos de Temperatura Promedio");
                Console.Write("Opción: ");
                try
                {
                    
                    int opccion = int.Parse(Console.ReadLine());
                    switch (opccion)
                    {
                        case 1:
                            Console.WriteLine("Ingrese la hora de inicio de la ventilacion:");
                            HoraSistema = DateTime.Parse(Console.ReadLine());
                            Console.WriteLine("Ingrese la hora fin de la ventilacion: ");
                            HoraSistemaFin = DateTime.Parse(Console.ReadLine());
                            Ventilacion();
                            break;
                        case 2:
                            Temperatura();
                            break;
                        case 3:
                            PromedioTemperatura();
                            break;

                    }
                }
                catch (Exception)
                {
                    
                    throw new Exception("No ingreso ningún horario");
                }
                Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");


            }

            void Ventilacion()
            {
                

                for (int i = 1; i <= Habitacion.Length; i++)
                {
                    Console.WriteLine($"Inicio de la hora de la ventilacion de la habitacion #{i}");
                    HoraInicio = DateTime.Parse(Console.ReadLine());
                    Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");

                   
                }
                for (int j = 1; j <= Habitacion.Length; j++)
                {
                    Console.WriteLine($"Fin de la hora de la ventilacion de la habitacion #{j}");
                    HoraFin = DateTime.Parse(Console.ReadLine());
                    Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
                }
                Console.ReadKey();
                Console.Clear();
                MostrasEstadosVentilacion();

            }
            void Temperatura()
            {
                

                
                for (int i = 0; i < HabitacionMin.Count(); i++)
                {
                    do
                    {

                        Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
                        Console.WriteLine($"Temperatura mínima de la Habitación #{i +1}:");
                        HabitacionMin[i] = int.Parse(Console.ReadLine());
                        if (HabitacionMin[i] <= 18)
                        {
                            Console.WriteLine("La temperatura minima es de 18°C");
                        }
                        Console.WriteLine();

                        Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
                    } while (HabitacionMin[i] <= 18);
                    

                }

                for (int j = 0; j < HabitacionMax.Count(); j++)
                {
                    Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
                    Console.WriteLine($"Temperatura máxima de la Habitación #{j+1}:");
                    HabitacionMax[j] = int.Parse(Console.ReadLine());
                }

                Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
                Console.WriteLine("Las temperaturas son:");
                Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
                for (int i = 0; i < HabitacionMin.Length; i++)
                {
                    Console.WriteLine($"La temperatura Mínima de la habitacion {i+1} es: " + HabitacionMin[i] + " C°");
                }
                Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
                for (int j = 0; j < HabitacionMin.Length; j++)
                {
                    Console.WriteLine($"La temperatura Máxima de la habitacion {j+1} es: " + HabitacionMax[j] + " C°");
                }

                for (int i = 0; i < HabitacionMin.Length; i++)
                {
                    PromMin += HabitacionMin[i] / 2;
                }

                for (int i = 0; i < HabitacionMax.Length; i++)
                {
                    PromMax += HabitacionMax[i] / 2;
                }
                Console.ReadKey();
            }
            void PromedioTemperatura()
            {
                Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
                Console.WriteLine("Promedio de la Temperatura Minima: " + PromMin);
                Console.WriteLine("Promedio de la Temperatura Maxima: " + PromMax);
                Console.WriteLine("Presione enter....");
                Console.ReadKey();
            }

            void MostrasEstadosVentilacion()
            {
                    if (HoraInicio != HoraSistema && HoraFin != HoraSistemaFin)
                    {
                        for (int j = 1; j <= Habitacion.Length; j++)
                        {
                            Console.WriteLine($"La ventilacion de la habitacion {j} esta apagada");
                        }
                    }
                    else if (HoraInicio == HoraSistema && HoraFin == HoraSistemaFin)
                    {

                        for (int l = 1; l <= Habitacion.Length; l++)
                        {
                            Console.WriteLine($"La ventilacion de la habitacion {l} esta encendida");
                        }
                    }

                Console.ReadKey();
            }
        }
    }
}
