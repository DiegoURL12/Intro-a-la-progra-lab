﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L9_Dl_1069322
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int modelo = 0;
            double precio = 0.00;
            string marca = "";
            bool disponible = false;
            string SIdisponible = "";
            double TipoCambioDolar = 7.80;
            double DescuentoAplicado = 0.00;

            Console.WriteLine("Ingrese modelo de carro:");
            modelo = int.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese precio");
            precio = double.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese tipo de marca:");
            marca = Console.ReadLine();

            Console.WriteLine("¿Está disponible?");
            SIdisponible = (Console.ReadLine());


            if (SIdisponible == "Disponible")
            {
                disponible = true;
            }

            Console.WriteLine("Ingrese descuento:");
            DescuentoAplicado = double.Parse(Console.ReadLine());

            mostrarinformacion(modelo, precio, marca, SIdisponible, TipoCambioDolar, DescuentoAplicado);

            Console.ReadKey();
        }
        static void mostrarinformacion(int modelo, double precio, string marca, string SIdisponible, double TipoCambioDolar, double Descuento)
        {
            double descuento = precio - precio * (Descuento / 100);

            double cambio = descuento / TipoCambioDolar;

            Console.WriteLine("Marca:" + marca + ". Modelo:" + modelo + ". Precio:" + descuento + ". Precio en Dolares:" + cambio + ". Mostrar disponibilidad:" + SIdisponible);
        }
    }
}