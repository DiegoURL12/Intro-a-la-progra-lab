﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T9_DL_1069322
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int Modelo = 0;
            double precio = 0.00;
            string marca = "";
            double IVA = 0.12;

            Console.WriteLine("Ingrese modelo de la motocicleta:");
            Modelo = int.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese precio:");
            precio = double.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese marca:");
            marca = Console.ReadLine();

            Console.WriteLine("Ingrese el % IVA:");
            IVA = double.Parse(Console.ReadLine());

            mostrarinformacion(Modelo, precio, marca, IVA);

            Console.ReadKey();
        }
        static void mostrarinformacion(int Modelo, double precio, string marca, double IVA)
        {
            double impuesto = precio + (precio * 0.12);
            double impIVA = (precio * 0.12);

            Console.WriteLine("Marca:" + marca + ". Modelo:" + Modelo + ". Precio sin IVA:" + precio + ". Precio con IVA:" + impuesto + ". Solo IVA:" + impIVA);
        }
    }
}
