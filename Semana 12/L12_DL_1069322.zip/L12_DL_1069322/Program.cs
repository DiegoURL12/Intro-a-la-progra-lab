﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L12_DL_1069322

{
    internal class Program
    {
        static void Main(string[] args)
        {
            int suma = 0;
            double prom = 0;
            Random num = new Random();

            int[,] matriz = new int[4, 5];
            for (int f = 0; f < 4; f++)
            {
                for (int c = 0; c < 5; c++)
                {
                    matriz[f, c] = num.Next(50);
                    suma = suma + matriz[f, c];
                }
            }
            prom = suma / matriz.Length;
            Console.WriteLine("Suma de la matriz: " + suma);
            Console.WriteLine("Promedio de la matriz : " + prom);
            Console.WriteLine("Matriz Uitilizada:");

            int[,] matrizA = new int[4, 5];
            for (int f = 0; f < 4; f++)
            {
                for (int c = 0; c < 5; c++)
                {
                    matriz[f, c] = num.Next(50);
                }

            }
            int[,] matrizB = new int[4, 5];
            for (int f = 0; f < 4; f++)
            {
                for (int c = 0; c < 5; c++)
                {
                    matrizB[f, c] = matriz[f, c] + matrizA[f, c];
                    Console.Write(matrizB[f, c] + " ");
                }
                Console.WriteLine();
            }

            Console.ReadKey();
        }
    }
}
