﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L10_DL1069322
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int cantidad = 0;
            int contador = 0;
            string usuario;
            string contraseña;
            bool res = false;


            while (cantidad < 3)
            {
                Console.WriteLine("Ingrese su nombre de usuario");
                usuario = Console.ReadLine();
                Console.WriteLine("Ingrese contraseña");
                contraseña = Console.ReadLine();

                res = login(usuario, contraseña);
                if (res == true)
                {
                    cantidad = 3;
                    Console.WriteLine("Bienvenido");
                }
                else
                {
                    Console.WriteLine("Error ingrese de nuevo su usuario o contraseña, su cantidad de intentos es: " + contador);
                    contador++;
                    cantidad++;
                }
                if (contador == 3)
                {
                    Console.WriteLine("Sin oprtunidades restantes");
                }

            }

            Console.ReadKey();
        }
        public static bool login(string usuario, string contra)
        {
            if (usuario == "Usuario1" && contra == "Asdasd")
            {
                return true;
            }
            else
            {
                return false;

            }
        }
    }
}